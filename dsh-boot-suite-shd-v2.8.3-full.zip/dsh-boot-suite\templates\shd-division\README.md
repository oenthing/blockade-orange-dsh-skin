# shd-division · 全境封锁皮肤

黑色 HUD 底板 + 全境封锁橙，Agency FB 窄体标识，SHD 鹰徽位图，ISAC 真声台词。
不改引擎的时序与交互，只给引擎加了两个**模板可用的能力**（见下），其余全是数据 + 一层 CSS。

| 文件 | 说明 |
|---|---|
| `template.json` | 分幕文案 / 配色 / 标识 / 音频槽，纯数据 |
| `assets/shd-logo.png` | SHD 鹰徽，已抠成带 alpha 的 768² PNG（黑底上直接叠） |
| `assets/bg.mp4` | 背景循环视频（1920×1080 / 60fps / 6.03s / 1.4MB，无音轨） |
| `assets/line-1..13.mp3` | ISAC 语音，来源见 `../../AUDIO-FIELDS.md` 同源工程的说明 |

## 背景视频

```json
"background": { "video": "assets/bg.mp4", "opacity": 0.72 }
```

- 只在洗白之后淡入 —— 黑幕那两秒仍然纯黑，仪式感不破
- **不要叠圆**：准星的两圈弧（`.dsu-ret-rot-a` 橙 / `.dsu-ret-rot-b` 白）在 shd 皮肤里全部关掉，
  环交给壁纸自带的那圈；我们只留内侧两个小角标和三个分点，负责"仪表感"
- **圆心跟着 LOGO 走**：`transform: translateY(-1.7%) scale(1.134)`
  - 中央徽标实测在 y≈348（1280×720 基准），所以把壁纸中心从 360 挪到 348 —— 鹰徽正好落在壁纸轮毂上
  - 倍率 1.134 让壁纸最外那圈细刻度环（r=307px @1920）落在 232px，也就是原来的准星半径上；
    换别的壁纸要重量：截一帧、从中心量最外圈半径，代入 `232 / (r × 0.6667)`
  - 壁纸自身缓慢呼吸 ±3%，所以只保证"看着是一圈"，不追像素
- 上面压一层径向遮罩（中心 0.5 → 边缘 0.88），保证状态字永远比画面亮
- 删掉 `background` 字段就回到纯色底板；解码失败也只是背景不显示，动画照走

## 台词与分幕

| 幕 | 中文 | 英文 | 音频 | 实际台词 |
|---|---|---|---|---|
| 1 | 需授权 · 接入 SHD 网络 | ACCESS REQUIRED · SHD NETWORK | line-1 | All ISAC systems are confirmed online. |
| 2 | 特工身份核验 | AGENT IDENTITY VERIFICATION | line-2 | Identity confirmed. |
| 3 | 接入请求已接收 | ACCESS REQUEST RECEIVED | line-3 | Accessing network. |
| 4 | 读取权限中 | PERMISSION READ IN PROGRESS | line-4 | Assessing security system. |
| 5 | 核验通过 · 权限已授予 | VERIFIED · ACCESS GRANTED | line-5 | Security protocols deactivated. |
| — | 终幕「欢迎 XX 访问」 | WELCOME TO / SHD | 无 | 引擎按设计不出人声 |

备用（已随模板打包，改 `steps[].audio` 就能换）：
`line-6` Access granted. · `line-7` Establishing uplink. · `line-8` Tracking signal.
· `line-9` Analysis complete. · `line-10` Uploading coordinates. · `line-11` System reset initiated.
· `line-12` Intelligent System Analytic Computer is activated. · `line-13` Alert!

## 引擎侧为它加的两个能力（向后兼容）

1. **`template.logo`**：`{ image, blend?, label?, labelWide? }`
   给了 `image` 就把黑幕、中央装配区、终幕三处的鲸鱼路径换成位图；
   `assembleLogo()` 对应改成「虚焦 → 合焦」的落位动画（无 `image` 时一切照旧走原来的描线）。
2. **`style: "shd"`**：给根节点加 `.dsu-shd`，`:hover`/皮肤样式全部收在这一个类下，
   不污染 `archive-warm` 等老模板。字体、橙配色、机框、切角按钮都在 `lib/splash.css` 末尾那一段。
3. **`template.copy`**：引擎里原本写死的两句底部文案可以覆盖了 ——
   `bootZh/bootEn`（底板出来后那句「系统自检中…」）、
   `finaleZh/finaleEn`（终幕底部那句「身份验证完成，会话已建立」）。
   不写就完全保持原句，老模板零影响。

## 切回/切走

`~/.dsh/dsh-startup.json` 的 `template` 字段：

```json
{ "template": "shd-division", "theme": "dark", "brand1": "SHD", ... }
```

想保留两套皮肤，就复制一份 `dsh-startup.json`，替换 `template` 与品牌字段即可。

## 版权

ISAC 语音来自《全境封锁》（Ubisoft）游戏内语音，**仅限本机自用**。
本模板的语音文件已随本机目录存在，**不要随插件发布包分发**；上架版请删掉 `assets/line-*.mp3`
（引擎会自动回落到 TTS，用 `steps[].say` 的英文句子朗读）。
SHD 鹰徽图片由本机使用者提供，同样不随包发布。
